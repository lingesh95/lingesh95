import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BookingPage extends StatelessWidget {
  final ValueNotifier<bool> isDarkMode = ValueNotifier(false);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: isDarkMode,
      builder: (context, isDark, _) {
        return MyHomePage(
          title: 'app',
          isDarkMode: isDark,
          onThemeChanged: (value) {
            isDarkMode.value = value;
          },
        );
      },
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({
    super.key,
    required this.title,
    required this.isDarkMode,
    required this.onThemeChanged,
  });

  final String title;
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey.shade800 : Colors.grey.shade200,
      appBar: AppBar(
        title: const Text("TRAIN TICKET BOOKING"),
        backgroundColor: Colors.orange[400],
        elevation: 50.0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const SizedBox(height: 50),
            ListTile(
              title: const Text('Profile'),
              trailing: const Icon(Icons.person),
            ),
            const Divider(),
            ListTile(
              title: const Text('Settings'),
              trailing: const Icon(Icons.settings),
              onTap: () {
                onThemeChanged(!isDarkMode);
              },
            ),
            const Divider(),
            ListTile(
              title: const Text('About Us'),
              trailing: const Icon(Icons.info_outline),
            ),
            const Divider(),
            ListTile(
              title: const Text('Logout'),
              trailing: const Icon(Icons.output_rounded),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 1, width: 1,),
            Container(
              height: 150,
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(10, 40, 10, 40),
              color: Colors.grey.shade300,
              child: Column(
                children: [
                  Text(
                    "WELCOME TO Train Ticket Booking Portal",
                    style: TextStyle(
                      fontSize: 28,
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    "TICKET BOOKING",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            UserTypeDropdown(),
          ],
        ),
      ),
    );
  }
}

class UserTypeDropdown extends StatefulWidget {
  @override
  _UserTypeDropdownState createState() => _UserTypeDropdownState();
}

class _UserTypeDropdownState extends State<UserTypeDropdown> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _mobileController = TextEditingController();
  final ValueNotifier<String?> _selectedFromLocation = ValueNotifier<String?>(null);
  final ValueNotifier<String?> _selectedToLocation = ValueNotifier<String?>(null);
  final ValueNotifier<String?> _passengerCount = ValueNotifier<String?>(null);

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    super.dispose();
  }

  Future<void> _submitData() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseFirestore.instance.collection('bookings').add({
          'name': _nameController.text,
          'mobile': _mobileController.text,
          'from': _selectedFromLocation.value,
          'to': _selectedToLocation.value,
          'passenger_count': _passengerCount.value,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Booking successful!')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SizedBox(height: 20, width: double.infinity),
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'NAME',
                  labelStyle: TextStyle(
                    color: Colors.orangeAccent,
                  ),
                  prefixIcon: Icon(
                    Icons.person,
                    color: Colors.orangeAccent,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color: Colors.orangeAccent,
                    ),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _mobileController,
                decoration: InputDecoration(
                  labelText: 'MOBILE',
                  labelStyle: TextStyle(
                    color: Colors.orangeAccent,
                  ),
                  prefixIcon: Icon(
                    Icons.phone,
                    color: Colors.orangeAccent,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                    borderSide: BorderSide(
                      color: Colors.orangeAccent,
                    ),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your mobile number';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<String?>(
                valueListenable: _passengerCount,
                builder: (context, selectedCount, _) {
                  return DropdownButtonFormField<String>(
                    value: selectedCount,
                    items: ['1', '2', '3', '4', '5']
                        .map((count) => DropdownMenuItem(
                      value: count,
                      child: Text(count),
                    ))
                        .toList(),
                    onChanged: (value) {
                      _passengerCount.value = value;
                    },
                    decoration: InputDecoration(
                      labelText: 'PASSENGER COUNT',
                      labelStyle: TextStyle(color: Colors.orangeAccent),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: Colors.orangeAccent,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select passenger count';
                      }
                      return null;
                    },
                  );
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<String?>(
                valueListenable: _selectedFromLocation,
                builder: (context, selectedFromLocation, _) {
                  return DropdownButtonFormField<String>(
                    value: selectedFromLocation,
                    items: ['CHENNAI', 'COIMBATORE', 'BANGALORE']
                        .map((location) => DropdownMenuItem(
                      value: location,
                      child: Text(location),
                    ))
                        .toList(),
                    onChanged: (value) {
                      _selectedFromLocation.value = value;
                    },
                    decoration: InputDecoration(
                      labelText: 'From',
                      labelStyle: TextStyle(color: Colors.orangeAccent),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: Colors.orangeAccent,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a departure location';
                      }
                      return null;
                    },
                  );
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<String?>(
                valueListenable: _selectedToLocation,
                builder: (context, selectedToLocation, _) {
                  return DropdownButtonFormField<String>(
                    value: selectedToLocation,
                    items: ['CHENNAI', 'COIMBATORE', 'BANGALORE']
                        .map((location) => DropdownMenuItem(
                      value: location,
                      child: Text(location),
                    ))
                        .toList(),
                    onChanged: (value) {
                      _selectedToLocation.value = value;
                    },
                    decoration: InputDecoration(
                      labelText: 'To',
                      labelStyle: TextStyle(color: Colors.orangeAccent),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20.0),
                        borderSide: BorderSide(
                          color: Colors.orangeAccent,
                        ),
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a destination location';
                      }
                      return null;
                    },
                  );
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 3,
                ),
                onPressed: _submitData,
                child: Text(
                  'Submit',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
