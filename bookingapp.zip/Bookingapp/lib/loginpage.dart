import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:bookingapp/frontpage.dart';
import 'package:bookingapp/signuppage.dart';

class LoginPage extends StatelessWidget {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final ValueNotifier<bool> _isEmailValid = ValueNotifier(true);
  final ValueNotifier<bool> _isPasswordValid = ValueNotifier(true);
  final ValueNotifier<bool> _isPasswordVisible = ValueNotifier(false);
  final ValueNotifier<bool> _loginInProgress = ValueNotifier(false);

  void _validateEmail(String email) {
    final emailRegExp = RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$');
    _isEmailValid.value = emailRegExp.hasMatch(email);
  }

  void _validatePassword(String password) {
    final passwordRegExp = RegExp(r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$');
    _isPasswordValid.value = password.isNotEmpty && passwordRegExp.hasMatch(password);
  }

  Future<void> _loginWithEmailAndPassword(BuildContext context, String email, String password) async {
    _loginInProgress.value = true;

    try {
      UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => frontpage()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == "user-not-found") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("No user found for that email")),
        );
      } else if (e.code == "wrong-password") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Wrong password provided for that user")),
        );
      }
    } finally {
      _loginInProgress.value = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("TRAIN TICKET BOOKING"),
        backgroundColor: Colors.orange[400],
        elevation: 50.0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 100),
              ValueListenableBuilder<bool>(
                valueListenable: _isEmailValid,
                builder: (context, isValid, child) {
                  return TextField(
                    controller: _emailController,
                    onChanged: _validateEmail,
                    decoration: InputDecoration(
                      labelText: 'Email',
                      errorText: isValid ? null : 'Enter a valid email',
                      prefixIcon: Icon(
                        Icons.email,
                        color: Colors.grey.shade600,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<bool>(
                valueListenable: _isPasswordVisible,
                builder: (context, isVisible, child) {
                  return ValueListenableBuilder<bool>(
                    valueListenable: _isPasswordValid,
                    builder: (context, isValid, child) {
                      return TextField(
                        controller: _passwordController,
                        obscureText: !isVisible,
                        onChanged: _validatePassword,
                        decoration: InputDecoration(
                          labelText: 'Password',
                          errorText: isValid ? null : 'Password must contain upper, lower, digit, special char.',
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Colors.grey.shade600,
                          ),
                          suffixIcon: IconButton(
                            onPressed: () {
                              _isPasswordVisible.value = !isVisible;
                            },
                            icon: Icon(
                              isVisible ? Icons.visibility_off : Icons.visibility,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.grey.shade200,
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<bool>(
                valueListenable: _loginInProgress,
                builder: (context, inProgress, child) {
                  return ElevatedButton(
                    child: inProgress
                        ? CircularProgressIndicator(color: Colors.white)
                        : const Text('Login'),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.orangeAccent),
                    ),
                    onPressed: inProgress
                        ? null
                        : () {
                      if (_emailController.text.isEmpty ||
                          !_isEmailValid.value ||
                          _passwordController.text.isEmpty ||
                          !_isPasswordValid.value) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Please fill all the fields correctly')),
                        );
                        return;
                      }
                      _loginWithEmailAndPassword(context, _emailController.text, _passwordController.text);
                    },
                  );
                },
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'New User',
                    style: TextStyle(
                      color: Colors.orangeAccent,
                    ),
                  ),
                  SizedBox(width: 5),
                  InkWell(
                    onTap: () {
                      print('account tapped');
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Signup(), // Replace with your Signup widget
                        ),
                      );
                    },
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                        color: Colors.orangeAccent,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
