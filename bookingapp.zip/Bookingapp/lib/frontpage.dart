import 'package:bookingapp/bookingpage.dart';
import 'package:flutter/material.dart';


class frontpage extends StatefulWidget {
  frontpage({super.key});

  @override
  _frontpageState createState() => _frontpageState();
}

class _frontpageState extends State<frontpage> {
  bool isDarkMode = false;

  @override
  Widget build(BuildContext context) {
    return MyHomePage(
      title: 'app',
      isDarkMode: isDarkMode,
      onThemeChanged: (value) {
        setState(() {
          isDarkMode = value;
        });
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title, required this.isDarkMode, required this.onThemeChanged});

  final String title;
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        title: const Text("TRAIN TICKET BOOKING"),
        backgroundColor: Colors.orange[400],
        elevation: 50.0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const SizedBox(height: 50),
            ListTile(
              title: const Text('Profile'),
              trailing: const Icon(Icons.person),
            ),
            const Divider(),
            const ListTile(
              title: Text('ID-Card'),
              trailing: Icon(Icons.perm_contact_cal_rounded),
            ),
            const Divider(),
            ListTile(
              title: const Text('Settings'),
              trailing: const Icon(Icons.settings),
            ),
            const Divider(),
            const ListTile(
              title: Text('About Us'),
              trailing: Icon(Icons.info_outline),
            ),
            const Divider(),
            const ListTile(
              title: Text('Logout'),
              trailing: Icon(Icons.output_rounded),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 5),
            Container(
              height: 150,
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(10, 40, 10, 40),
              color: Colors.grey.shade300,
              child: Column(
                children: [
                  Text(
                    " WELCOME TO TICKET BOOKING PORTAL",
                    style: TextStyle(
                      fontSize: 28,
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    "TICKET BOOKING",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height - 320,
              child: ListView(
                children: [
                  SizedBox(height: 5),
                  Card(
                    color: Colors.white60,
                    child: ListTile(
                      title: Text('Ticket Booking', style: TextStyle(fontSize: 20)),
                      trailing: Icon(Icons.book_online),
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => BookingPage()));
                      },
                     ),
                  ),
                  SizedBox(height: 5),
                  Card(
                    color: Colors.white60,
                    child: ListTile(
                      title: Text('View Status', style: TextStyle(fontSize: 20)),
                      trailing: Icon(Icons.table_view_rounded),
                    ),
                  ),
                  SizedBox(height: 5),
                  Card(
                    color: Colors.white60,
                    child: ListTile(
                      title: Text('PNR STATUS', style: TextStyle(fontSize: 20)),
                      trailing: Icon(Icons.calendar_month_rounded),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
