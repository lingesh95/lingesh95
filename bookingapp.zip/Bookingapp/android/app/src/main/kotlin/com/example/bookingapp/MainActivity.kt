package com.example.bookingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
